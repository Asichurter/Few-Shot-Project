# Few-Shot-Project
Project repository for 2019 project:
 
Malware detection under few-shot circumstances
